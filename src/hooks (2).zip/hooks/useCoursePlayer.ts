// src/hooks/useCoursePlayer.ts
"use client";

import { useState, useCallback, useMemo, useRef, useEffect } from "react";
import { doc, getDoc, collection, getDocs, orderBy, query } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { enrollStudent } from "@/services/enrollmentService";
import { finishLessonServerAction } from "@/app/actions/courseActions";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";

// Hooks Core (Seguros)
import { 
  useSafeState, 
  useAsyncEffect, 
  useMounted,
  useOnlineStatus,
  useReconnectListener 
} from "@/hooks/core";

/**
 * ============================================================================
 * TIPOS
 * ============================================================================
 */

export interface Lesson {
  id: string;
  title: string;
  videoUrl: string;
  order: number;
  xpReward: number;
  duration?: number;
  durationFormatted?: string;
}

export interface Module {
  id: string;
  title: string;
  order: number;
  lessons: Lesson[];
  hasQuiz?: boolean;
}

export type ContentType = "lesson" | "quiz";

export interface CoursePlayerState {
  loading: boolean;
  error: string | null;
  modules: Module[];
  activeLesson: Lesson | null;
  activeModuleId: string | null;
  activeContentType: ContentType;
  completedLessons: string[];
  completedQuizzes: string[];
  markingComplete: boolean;
  courseTitle?: string;
  progress: number;
  isOnline: boolean;
}

/**
 * ============================================================================
 * HELPERS
 * ============================================================================
 */

/** Carrega módulos do Syllabus (otimizado) */
async function loadFromSyllabus(
  courseId: string,
  syllabus: Array<{ id: string; title: string; lessons: Array<{ id: string; title: string; duration?: number }> }>,
  signal?: AbortSignal
): Promise<Module[]> {
  const modules: Module[] = [];

  for (let i = 0; i < syllabus.length; i++) {
    // Verifica cancelamento
    if (signal?.aborted) {
      throw new DOMException('Operação cancelada', 'AbortError');
    }

    const syllabusModule = syllabus[i];
    
    // Busca dados completos das aulas
    const lessonsRef = collection(db, "courses", courseId, "modules", syllabusModule.id, "lessons");
    const lessonsQuery = query(lessonsRef, orderBy("order", "asc"));
    const lessonsSnap = await getDocs(lessonsQuery);

    const lessons: Lesson[] = lessonsSnap.docs.map((lessonDoc, idx) => {
      const data = lessonDoc.data();
      return {
        id: lessonDoc.id,
        title: data.title || `Aula ${idx + 1}`,
        videoUrl: data.videoUrl || "",
        order: data.order ?? idx,
        xpReward: data.xpReward ?? 10,
        duration: data.duration,
        durationFormatted: data.durationFormatted,
      };
    });

    // Verifica se o módulo tem quiz
    const questionsRef = collection(db, "courses", courseId, "modules", syllabusModule.id, "questions");
    const questionsSnap = await getDocs(questionsRef);
    const hasQuiz = !questionsSnap.empty;

    modules.push({
      id: syllabusModule.id,
      title: syllabusModule.title,
      order: i,
      lessons,
      hasQuiz,
    });
  }

  return modules;
}

/** Carrega módulos diretamente do Firestore (fallback) */
async function loadFromFirestore(
  courseId: string,
  signal?: AbortSignal
): Promise<Module[]> {
  const modulesRef = collection(db, "courses", courseId, "modules");
  const modulesQuery = query(modulesRef, orderBy("order", "asc"));
  const modulesSnap = await getDocs(modulesQuery);

  const modules: Module[] = [];

  for (const moduleDoc of modulesSnap.docs) {
    // Verifica cancelamento
    if (signal?.aborted) {
      throw new DOMException('Operação cancelada', 'AbortError');
    }

    const moduleData = moduleDoc.data();

    // Carrega aulas do módulo
    const lessonsRef = collection(db, "courses", courseId, "modules", moduleDoc.id, "lessons");
    const lessonsQuery = query(lessonsRef, orderBy("order", "asc"));
    const lessonsSnap = await getDocs(lessonsQuery);

    const lessons: Lesson[] = lessonsSnap.docs.map((lessonDoc, idx) => {
      const data = lessonDoc.data();
      return {
        id: lessonDoc.id,
        title: data.title || `Aula ${idx + 1}`,
        videoUrl: data.videoUrl || "",
        order: data.order ?? idx,
        xpReward: data.xpReward ?? 10,
        duration: data.duration,
        durationFormatted: data.durationFormatted,
      };
    });

    // Verifica se tem quiz
    const questionsRef = collection(db, "courses", courseId, "modules", moduleDoc.id, "questions");
    const questionsSnap = await getDocs(questionsRef);
    const hasQuiz = !questionsSnap.empty;

    modules.push({
      id: moduleDoc.id,
      title: moduleData.title || `Módulo ${modules.length + 1}`,
      order: moduleData.order ?? modules.length,
      lessons,
      hasQuiz,
    });
  }

  return modules;
}

/** Encontra posição inicial */
function findInitialPosition(
  modules: Module[],
  completedLessons: string[],
  completedQuizzes: string[]
): { moduleId: string | null; lesson: Lesson | null; contentType: ContentType } {
  if (modules.length === 0) {
    return { moduleId: null, lesson: null, contentType: "lesson" };
  }

  for (const module of modules) {
    for (const lesson of module.lessons) {
      if (!completedLessons.includes(lesson.id)) {
        return {
          moduleId: module.id,
          lesson,
          contentType: "lesson",
        };
      }
    }

    if (module.hasQuiz && !completedQuizzes.includes(module.id)) {
      return {
        moduleId: module.id,
        lesson: module.lessons[module.lessons.length - 1] || null,
        contentType: "quiz",
      };
    }
  }

  // Se tudo foi completado, volta pro início
  const firstModule = modules[0];
  return {
    moduleId: firstModule.id,
    lesson: firstModule.lessons[0] || null,
    contentType: "lesson",
  };
}

/**
 * ============================================================================
 * HOOK: useCoursePlayer
 * ============================================================================
 * Hook robusto para gerenciar o estado do player de curso.
 * Usa hooks core para garantir cleanup adequado e prevenir memory leaks.
 */
export function useCoursePlayer(courseId: string) {
  const { user } = useAuth();
  const { addToast } = useToast();
  const isMounted = useMounted();

  // Estados principais (usando useSafeState para prevenir memory leaks)
  const [loading, setLoading] = useSafeState(true);
  const [error, setError] = useSafeState<string | null>(null);
  const [modules, setModules] = useSafeState<Module[]>([]);
  const [completedLessons, setCompletedLessons] = useSafeState<string[]>([]);
  const [completedQuizzes, setCompletedQuizzes] = useSafeState<string[]>([]);
  const [courseTitle, setCourseTitle] = useSafeState<string>("");
  
  // Estados de navegação
  const [activeModuleId, setActiveModuleId] = useSafeState<string | null>(null);
  const [activeLesson, setActiveLesson] = useSafeState<Lesson | null>(null);
  const [activeContentType, setActiveContentType] = useSafeState<ContentType>("lesson");
  const [markingComplete, setMarkingComplete] = useSafeState(false);

  // Ref para controlar carregamento único e invalidação
  const loadAttemptRef = useRef(0);

  // Status de conexão
  const { isOnline } = useOnlineStatus({
    onOffline: () => {
      addToast("Você está offline. Seu progresso será salvo quando a conexão voltar.", "warning");
    },
    onReconnect: () => {
      addToast("Conexão restaurada!", "success");
    }
  });

  /**
   * ============================================================================
   * EFEITO: Carregamento Inicial de Dados
   * ============================================================================
   */
  useAsyncEffect(
    async (signal) => {
      // Não carrega se não tiver courseId ou user
      if (!courseId || !user) {
        setLoading(false);
        return;
      }

      // Incrementa tentativa (para invalidar carregamentos anteriores)
      const currentAttempt = ++loadAttemptRef.current;

      setLoading(true);
      setError(null);

      try {
        // ========================================
        // 1. CARREGAR DADOS DO CURSO
        // ========================================
        const courseRef = doc(db, "courses", courseId);
        const courseSnap = await getDoc(courseRef);

        // Verifica cancelamento
        if (signal.aborted || currentAttempt !== loadAttemptRef.current) return;

        if (!courseSnap.exists()) {
          throw new Error("Curso não encontrado");
        }

        const courseData = courseSnap.data();
        setCourseTitle(courseData.title || "");

        // Usa Syllabus cacheado se disponível
        let loadedModules: Module[] = [];

        if (courseData.syllabus && Array.isArray(courseData.syllabus)) {
          loadedModules = await loadFromSyllabus(courseId, courseData.syllabus, signal);
        } else {
          loadedModules = await loadFromFirestore(courseId, signal);
        }

        // Verifica cancelamento novamente
        if (signal.aborted || currentAttempt !== loadAttemptRef.current) return;

        // Ordena módulos por ordem
        loadedModules.sort((a, b) => a.order - b.order);

        // ========================================
        // 2. CARREGAR PROGRESSO DO ALUNO
        // ========================================
        const enrollmentId = `${user.uid}_${courseId}`;
        const enrollmentRef = doc(db, "enrollments", enrollmentId);
        const enrollmentSnap = await getDoc(enrollmentRef);

        if (signal.aborted || currentAttempt !== loadAttemptRef.current) return;

        let userCompletedLessons: string[] = [];
        let userCompletedQuizzes: string[] = [];

        if (enrollmentSnap.exists()) {
          const enrollmentData = enrollmentSnap.data();
          userCompletedLessons = enrollmentData.completedLessons || [];
          userCompletedQuizzes = enrollmentData.completedQuizzes || [];
        } else {
          // Auto-matrícula se não estiver matriculado
          try {
            await enrollStudent(user.uid, courseId);
          } catch (enrollError) {
            console.warn("Auto-matrícula falhou (pode já existir):", enrollError);
          }
        }

        // Verifica cancelamento final
        if (signal.aborted || currentAttempt !== loadAttemptRef.current) return;

        // ========================================
        // 3. DEFINIR ESTADO INICIAL
        // ========================================
        setModules(loadedModules);
        setCompletedLessons(userCompletedLessons);
        setCompletedQuizzes(userCompletedQuizzes);

        // Define primeiro módulo/aula não completada
        const initialState = findInitialPosition(
          loadedModules,
          userCompletedLessons,
          userCompletedQuizzes
        );

        setActiveModuleId(initialState.moduleId);
        setActiveLesson(initialState.lesson);
        setActiveContentType(initialState.contentType);

      } catch (err) {
        // Ignora erros de abort
        if (err instanceof DOMException && err.name === 'AbortError') {
          return;
        }

        const errorMessage = err instanceof Error ? err.message : "Erro ao carregar curso";
        console.error("Erro ao carregar curso:", err);
        setError(errorMessage);
        addToast(errorMessage, "error");
      } finally {
        // Só marca loading como false se ainda for a tentativa atual
        if (currentAttempt === loadAttemptRef.current) {
          setLoading(false);
        }
      }
    },
    [courseId, user?.uid],
    {
      onError: (err) => {
        console.error("Erro no carregamento:", err);
      }
    }
  );

  // Recarrega dados quando reconectar
  useReconnectListener(() => {
    if (courseId && user) {
      loadAttemptRef.current++;
    }
  });

  /**
   * ============================================================================
   * COMPUTED: Cálculo de progresso
   * ============================================================================
   */
  const progress = useMemo(() => {
    if (modules.length === 0) return 0;

    let totalItems = 0;
    let completedItems = 0;

    for (const module of modules) {
      totalItems += module.lessons.length;
      completedItems += module.lessons.filter(l => completedLessons.includes(l.id)).length;

      if (module.hasQuiz) {
        totalItems += 1;
        if (completedQuizzes.includes(module.id)) {
          completedItems += 1;
        }
      }
    }

    if (totalItems === 0) return 0;
    return Math.round((completedItems / totalItems) * 100);
  }, [modules, completedLessons, completedQuizzes]);

  /**
   * ============================================================================
   * COMPUTED: Verifica se existe próximo passo
   * ============================================================================
   */
  const hasNextStep = useMemo(() => {
    if (!activeModuleId || !activeLesson || modules.length === 0) return false;

    const currentModIndex = modules.findIndex(m => m.id === activeModuleId);
    if (currentModIndex === -1) return false;
    
    const currentMod = modules[currentModIndex];
    const currentLessonIndex = currentMod.lessons.findIndex(l => l.id === activeLesson.id);

    // Tem próxima aula neste módulo?
    if (currentLessonIndex < currentMod.lessons.length - 1) return true;

    // Se é lição e o módulo tem quiz, vai pro quiz
    if (activeContentType === 'lesson' && currentMod.hasQuiz) return true;

    // Se acabou o módulo/quiz, tem próximo módulo?
    if (currentModIndex < modules.length - 1) return true;

    return false;
  }, [modules, activeModuleId, activeLesson, activeContentType]);

  /**
   * ============================================================================
   * ACTION: Completar Aula
   * ============================================================================
   */
  const completeLesson = useCallback(async (lesson: Lesson, moduleId: string) => {
    if (!user || completedLessons.includes(lesson.id)) return;
    if (!isMounted()) return;

    setMarkingComplete(true);
    try {
      const token = await user.getIdToken();
      const result = await finishLessonServerAction(token, courseId, moduleId, lesson.id);

      if (!isMounted()) return;

      if (result.success) {
        setCompletedLessons(prev => [...prev, lesson.id]);
        if (result.leveledUp) {
          addToast(`🎉 PARABÉNS! Você subiu para o Nível ${result.newLevel}!`, "success");
        } else {
          addToast(`Aula concluída! +${result.xpEarned} XP`, "success");
        }
      } else {
        addToast(result.message || "Erro ao salvar progresso.", "error");
      }
    } catch (err) {
      if (!isMounted()) return;
      console.error("Erro ao completar aula:", err);
      addToast("Erro ao salvar progresso.", "error");
    } finally {
      if (isMounted()) {
        setMarkingComplete(false);
      }
    }
  }, [user, courseId, completedLessons, addToast, isMounted, setCompletedLessons, setMarkingComplete]);

  /**
   * ============================================================================
   * ACTION: Navegar para Próximo
   * ============================================================================
   */
  const navigateToNext = useCallback(() => {
    if (!hasNextStep) return;
    if (!activeModuleId || !activeLesson) return;

    const currentModIndex = modules.findIndex(m => m.id === activeModuleId);
    if (currentModIndex === -1) return;
    
    const currentMod = modules[currentModIndex];
    const currentLessonIndex = currentMod.lessons.findIndex(l => l.id === activeLesson.id);

    // 1. Próxima aula do mesmo módulo
    if (currentLessonIndex < currentMod.lessons.length - 1) {
      setActiveLesson(currentMod.lessons[currentLessonIndex + 1]);
      return;
    }

    // 2. Ir para o Quiz
    if (activeContentType === 'lesson' && currentMod.hasQuiz) {
      setActiveContentType('quiz');
      return;
    }

    // 3. Próximo Módulo
    if (currentModIndex < modules.length - 1) {
      const nextMod = modules[currentModIndex + 1];
      setActiveModuleId(nextMod.id);
      if (nextMod.lessons.length > 0) {
        setActiveLesson(nextMod.lessons[0]);
        setActiveContentType('lesson');
      }
    }
  }, [hasNextStep, activeModuleId, activeLesson, activeContentType, modules, setActiveLesson, setActiveModuleId, setActiveContentType]);

  /**
   * ============================================================================
   * ACTION: Selecionar Aula Específica
   * ============================================================================
   */
  const selectLesson = useCallback((moduleId: string, lesson: Lesson) => {
    setActiveModuleId(moduleId);
    setActiveLesson(lesson);
    setActiveContentType('lesson');
  }, [setActiveModuleId, setActiveLesson, setActiveContentType]);

  /**
   * ============================================================================
   * ACTION: Selecionar Quiz do Módulo
   * ============================================================================
   */
  const selectQuiz = useCallback((moduleId: string) => {
    const module = modules.find(m => m.id === moduleId);
    if (module && module.hasQuiz) {
      setActiveModuleId(moduleId);
      if (module.lessons.length > 0) {
        setActiveLesson(module.lessons[module.lessons.length - 1]);
      }
      setActiveContentType('quiz');
    }
  }, [modules, setActiveModuleId, setActiveLesson, setActiveContentType]);

  /**
   * ============================================================================
   * ACTION: Marcar Quiz como Completado
   * ============================================================================
   */
  const markQuizCompleted = useCallback((moduleId: string) => {
    setCompletedQuizzes(prev => {
      if (prev.includes(moduleId)) return prev;
      return [...prev, moduleId];
    });
  }, [setCompletedQuizzes]);

  /**
   * ============================================================================
   * ACTION: Recarregar Dados
   * ============================================================================
   */
  const reload = useCallback(() => {
    loadAttemptRef.current++;
    setLoading(true);
    setError(null);
  }, [setLoading, setError]);

  /**
   * ============================================================================
   * RETURN
   * ============================================================================
   */
  return {
    // Estados
    loading,
    error,
    modules,
    courseTitle,
    progress,
    isOnline,
    
    // Navegação atual
    activeLesson,
    activeModuleId,
    activeContentType,
    
    // Progresso do aluno
    completedLessons,
    completedQuizzes,
    
    // Estados de UI
    markingComplete,
    hasNextStep,
    
    // Setters
    setActiveLesson,
    setActiveModuleId,
    setActiveContentType,
    setCompletedQuizzes,
    
    // Actions
    completeLesson,
    navigateToNext,
    selectLesson,
    selectQuiz,
    markQuizCompleted,
    reload,
  };
}
