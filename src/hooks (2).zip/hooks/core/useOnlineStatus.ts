// src/hooks/core/useOnlineStatus.ts
// Hook para detectar e reagir a mudanças de status de conexão
// Permite sincronização automática quando volta online

import { useState, useEffect, useCallback, useRef } from 'react';

/**
 * Informações sobre o status de conexão
 */
export interface OnlineStatus {
  /** Se está conectado à internet */
  isOnline: boolean;
  
  /** Se estava offline e voltou (útil para sync) */
  wasOffline: boolean;
  
  /** Timestamp da última mudança de status */
  lastChanged: Date | null;
  
  /** Tempo total offline na sessão (em ms) */
  totalOfflineTime: number;
  
  /** Número de vezes que ficou offline */
  offlineCount: number;
}

/**
 * Opções do useOnlineStatus
 */
export interface OnlineStatusOptions {
  /** Callback quando fica online */
  onOnline?: () => void;
  
  /** Callback quando fica offline */
  onOffline?: () => void;
  
  /** Callback quando volta de offline para online */
  onReconnect?: (offlineDuration: number) => void;
  
  /** Se deve disparar evento global quando voltar online */
  dispatchReconnectEvent?: boolean;
}

/** Nome do evento global de reconexão */
export const RECONNECT_EVENT = 'app:reconnected';

/**
 * Hook para monitorar status de conexão
 * 
 * @example
 * // Uso básico
 * const { isOnline, wasOffline } = useOnlineStatus();
 * 
 * @example
 * // Com callbacks
 * const { isOnline } = useOnlineStatus({
 *   onReconnect: (duration) => {
 *     console.log(`Ficou offline por ${duration}ms`);
 *     syncPendingChanges();
 *   }
 * });
 * 
 * @example
 * // Reagindo a reconexão global
 * useEffect(() => {
 *   const handleReconnect = () => refetch();
 *   window.addEventListener('app:reconnected', handleReconnect);
 *   return () => window.removeEventListener('app:reconnected', handleReconnect);
 * }, []);
 */
export function useOnlineStatus(options: OnlineStatusOptions = {}): OnlineStatus {
  const {
    onOnline,
    onOffline,
    onReconnect,
    dispatchReconnectEvent = true,
  } = options;
  
  // Estado inicial
  const [status, setStatus] = useState<OnlineStatus>(() => ({
    isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
    wasOffline: false,
    lastChanged: null,
    totalOfflineTime: 0,
    offlineCount: 0,
  }));
  
  // Refs para tracking
  const offlineStartRef = useRef<number | null>(null);
  const optionsRef = useRef(options);
  
  // Atualiza ref das options
  optionsRef.current = options;
  
  // Handler para quando fica online
  const handleOnline = useCallback(() => {
    const offlineDuration = offlineStartRef.current 
      ? Date.now() - offlineStartRef.current 
      : 0;
    
    offlineStartRef.current = null;
    
    setStatus(prev => ({
      ...prev,
      isOnline: true,
      wasOffline: true,
      lastChanged: new Date(),
      totalOfflineTime: prev.totalOfflineTime + offlineDuration,
    }));
    
    // Callbacks
    optionsRef.current.onOnline?.();
    
    if (offlineDuration > 0) {
      optionsRef.current.onReconnect?.(offlineDuration);
      
      // Dispara evento global
      if (dispatchReconnectEvent && typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent(RECONNECT_EVENT, {
          detail: { offlineDuration }
        }));
      }
    }
  }, [dispatchReconnectEvent]);
  
  // Handler para quando fica offline
  const handleOffline = useCallback(() => {
    offlineStartRef.current = Date.now();
    
    setStatus(prev => ({
      ...prev,
      isOnline: false,
      lastChanged: new Date(),
      offlineCount: prev.offlineCount + 1,
    }));
    
    optionsRef.current.onOffline?.();
  }, []);
  
  // Registra listeners
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [handleOnline, handleOffline]);
  
  return status;
}

/**
 * Hook simplificado que retorna apenas boolean
 */
export function useIsOnline(): boolean {
  const { isOnline } = useOnlineStatus();
  return isOnline;
}

/**
 * Hook para executar ação quando reconectar
 */
export function useOnReconnect(callback: (offlineDuration: number) => void): void {
  useOnlineStatus({
    onReconnect: callback,
  });
}

/**
 * Hook para listener global de reconexão
 * Útil para componentes que precisam reagir à reconexão
 * mas não querem monitorar status continuamente
 */
export function useReconnectListener(callback: () => void): void {
  const callbackRef = useRef(callback);
  callbackRef.current = callback;
  
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    const handler = () => callbackRef.current();
    
    window.addEventListener(RECONNECT_EVENT, handler);
    return () => window.removeEventListener(RECONNECT_EVENT, handler);
  }, []);
}

/**
 * Componente Wrapper para mostrar UI quando offline
 */
export function useOfflineDetector(): {
  isOffline: boolean;
  offlineDuration: number | null;
} {
  const { isOnline } = useOnlineStatus();
  const [offlineDuration, setOfflineDuration] = useState<number | null>(null);
  const offlineStartRef = useRef<number | null>(null);
  const intervalRef = useRef<NodeJS.Timer | null>(null);
  
  useEffect(() => {
    if (!isOnline) {
      offlineStartRef.current = Date.now();
      
      // Atualiza duração a cada segundo
      intervalRef.current = setInterval(() => {
        if (offlineStartRef.current) {
          setOfflineDuration(Date.now() - offlineStartRef.current);
        }
      }, 1000);
    } else {
      offlineStartRef.current = null;
      setOfflineDuration(null);
      
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isOnline]);
  
  return {
    isOffline: !isOnline,
    offlineDuration,
  };
}

export default useOnlineStatus;
