// src/hooks/core/index.ts
// Barrel export dos hooks core
// Estes hooks são a fundação para construir hooks mais complexos de forma segura

// Estado seguro
export { 
  useSafeState, 
  useSafeStateWithCallback, 
  useSafeStates 
} from './useSafeState';

// Montagem e ciclo de vida
export { 
  useMounted, 
  useMountedRef 
} from './useMounted';

// Efeitos assíncronos
export { 
  useAsyncEffect, 
  useAsyncEffectSimple, 
  useAsyncMount, 
  useAsyncEffectIf, 
  useAsyncEffectAll,
  type AsyncEffectStatus,
  type AsyncEffectOptions,
  type AsyncEffectResult 
} from './useAsyncEffect';

// Status de conexão
export { 
  useOnlineStatus, 
  useIsOnline, 
  useOnReconnect, 
  useReconnectListener,
  useOfflineDetector,
  RECONNECT_EVENT,
  type OnlineStatus,
  type OnlineStatusOptions 
} from './useOnlineStatus';

// Debounce e Throttle
export { 
  useDebounce, 
  useDebouncedCallback, 
  useThrottle, 
  useThrottledCallback,
  type DebounceOptions,
  type DebouncedCallbackResult 
} from './useDebounce';

// Retry e Recovery
export { 
  useRetry, 
  useRetryMutation,
  type UseRetryState,
  type UseRetryOptions,
  type UseRetryResult 
} from './useRetry';
