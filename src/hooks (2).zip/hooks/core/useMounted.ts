// src/hooks/core/useMounted.ts
// Hook para verificar se o componente ainda está montado
// Evita memory leaks ao tentar atualizar estado de componentes desmontados

import { useRef, useEffect, useCallback } from 'react';

/**
 * Hook que retorna se o componente está montado
 * 
 * @example
 * const isMounted = useMounted();
 * 
 * useEffect(() => {
 *   fetchData().then(data => {
 *     if (isMounted()) {
 *       setData(data);
 *     }
 *   });
 * }, [isMounted]);
 */
export function useMounted(): () => boolean {
  const mountedRef = useRef(false);
  
  useEffect(() => {
    mountedRef.current = true;
    
    return () => {
      mountedRef.current = false;
    };
  }, []);
  
  return useCallback(() => mountedRef.current, []);
}

/**
 * Hook que retorna uma ref que indica se está montado
 * Versão para quando você precisa da ref diretamente
 * 
 * @example
 * const mountedRef = useMountedRef();
 * 
 * if (mountedRef.current) {
 *   setData(data);
 * }
 */
export function useMountedRef(): React.MutableRefObject<boolean> {
  const mountedRef = useRef(false);
  
  useEffect(() => {
    mountedRef.current = true;
    
    return () => {
      mountedRef.current = false;
    };
  }, []);
  
  return mountedRef;
}

export default useMounted;
