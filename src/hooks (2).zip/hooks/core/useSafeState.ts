// src/hooks/core/useSafeState.ts
// Hook de estado seguro que previne updates em componentes desmontados
// Elimina warnings de "Can't perform a React state update on an unmounted component"

import { useState, useCallback, useRef, useEffect, Dispatch, SetStateAction } from 'react';

type SetStateFn<S> = Dispatch<SetStateAction<S>>;

/**
 * Hook de estado seguro que ignora updates após unmount
 * 
 * @example
 * const [data, setData] = useSafeState<User | null>(null);
 * 
 * useEffect(() => {
 *   fetchUser().then(user => {
 *     setData(user); // Seguro - não faz nada se desmontado
 *   });
 * }, []);
 */
export function useSafeState<S>(
  initialState: S | (() => S)
): [S, SetStateFn<S>] {
  const [state, setState] = useState(initialState);
  const mountedRef = useRef(true);
  
  useEffect(() => {
    mountedRef.current = true;
    
    return () => {
      mountedRef.current = false;
    };
  }, []);
  
  const safeSetState: SetStateFn<S> = useCallback((value) => {
    if (mountedRef.current) {
      setState(value);
    }
  }, []);
  
  return [state, safeSetState];
}

/**
 * Versão com callback opcional que é chamado após o update
 * Útil para debugging ou side effects
 */
export function useSafeStateWithCallback<S>(
  initialState: S | (() => S),
  callback?: (newState: S) => void
): [S, SetStateFn<S>] {
  const [state, safeSetState] = useSafeState(initialState);
  const callbackRef = useRef(callback);
  
  // Atualiza ref do callback sem causar re-render
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);
  
  const setStateWithCallback: SetStateFn<S> = useCallback((value) => {
    safeSetState((prevState) => {
      const newState = typeof value === 'function' 
        ? (value as (prev: S) => S)(prevState)
        : value;
      
      // Chama callback se existir
      if (callbackRef.current) {
        // Usa setTimeout para garantir que o estado foi atualizado
        setTimeout(() => callbackRef.current?.(newState), 0);
      }
      
      return newState;
    });
  }, [safeSetState]);
  
  return [state, setStateWithCallback];
}

/**
 * Hook para múltiplos estados relacionados
 * Útil quando você tem estados que sempre são atualizados juntos
 */
export function useSafeStates<T extends Record<string, unknown>>(
  initialStates: T
): [T, <K extends keyof T>(key: K, value: T[K]) => void, (updates: Partial<T>) => void] {
  const [states, setStates] = useSafeState<T>(initialStates);
  
  const setSingleState = useCallback(<K extends keyof T>(key: K, value: T[K]) => {
    setStates(prev => ({ ...prev, [key]: value }));
  }, [setStates]);
  
  const setMultipleStates = useCallback((updates: Partial<T>) => {
    setStates(prev => ({ ...prev, ...updates }));
  }, [setStates]);
  
  return [states, setSingleState, setMultipleStates];
}

export default useSafeState;
