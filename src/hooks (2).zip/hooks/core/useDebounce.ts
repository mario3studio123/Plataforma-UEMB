// src/hooks/core/useDebounce.ts
// Hook de debounce robusto com suporte a leading/trailing edge e cancelamento

import { useState, useEffect, useRef, useCallback, useMemo } from 'react';

/**
 * Opções do useDebounce
 */
export interface DebounceOptions {
  /** Executa imediatamente na primeira chamada */
  leading?: boolean;
  
  /** Executa após o delay (padrão: true) */
  trailing?: boolean;
  
  /** Tempo máximo de espera (útil para garantir execução) */
  maxWait?: number;
}

/**
 * Hook para debounce de valores
 * 
 * @example
 * const [searchTerm, setSearchTerm] = useState('');
 * const debouncedSearch = useDebounce(searchTerm, 300);
 * 
 * useEffect(() => {
 *   if (debouncedSearch) {
 *     searchAPI(debouncedSearch);
 *   }
 * }, [debouncedSearch]);
 */
export function useDebounce<T>(
  value: T,
  delay: number,
  options: DebounceOptions = {}
): T {
  const { leading = false, trailing = true } = options;
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  const isFirstRender = useRef(true);
  
  useEffect(() => {
    // Leading edge: atualiza imediatamente na primeira mudança
    if (leading && isFirstRender.current) {
      isFirstRender.current = false;
      setDebouncedValue(value);
      return;
    }
    
    isFirstRender.current = false;
    
    // Trailing edge: atualiza após delay
    if (trailing) {
      const timer = setTimeout(() => {
        setDebouncedValue(value);
      }, delay);
      
      return () => clearTimeout(timer);
    }
  }, [value, delay, leading, trailing]);
  
  return debouncedValue;
}

/**
 * Resultado do useDebouncedCallback
 */
export interface DebouncedCallbackResult<T extends (...args: any[]) => any> {
  /** Função debounced */
  debouncedFn: T;
  
  /** Cancela execução pendente */
  cancel: () => void;
  
  /** Executa imediatamente (flush) */
  flush: () => void;
  
  /** Se há execução pendente */
  isPending: boolean;
}

/**
 * Hook para debounce de callbacks/funções
 * 
 * @example
 * const { debouncedFn: saveProgress, cancel } = useDebouncedCallback(
 *   (progress: number) => {
 *     api.saveProgress(progress);
 *   },
 *   1000
 * );
 * 
 * // Na lógica do componente
 * saveProgress(50); // Será executado após 1s sem novas chamadas
 */
export function useDebouncedCallback<T extends (...args: any[]) => any>(
  callback: T,
  delay: number,
  options: DebounceOptions = {}
): DebouncedCallbackResult<T> {
  const { leading = false, trailing = true, maxWait } = options;
  
  // Refs para manter valores atuais
  const callbackRef = useRef(callback);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const maxWaitTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastArgsRef = useRef<Parameters<T> | null>(null);
  const lastCallTimeRef = useRef<number>(0);
  const lastInvokeTimeRef = useRef<number>(0);
  const pendingRef = useRef(false);
  
  // Atualiza ref do callback sem causar re-render
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);
  
  // Limpa timeouts no unmount
  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (maxWaitTimeoutRef.current) clearTimeout(maxWaitTimeoutRef.current);
    };
  }, []);
  
  // Função para invocar o callback
  const invokeCallback = useCallback(() => {
    if (lastArgsRef.current) {
      lastInvokeTimeRef.current = Date.now();
      pendingRef.current = false;
      callbackRef.current(...lastArgsRef.current);
      lastArgsRef.current = null;
    }
  }, []);
  
  // Cancela execução pendente
  const cancel = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    if (maxWaitTimeoutRef.current) {
      clearTimeout(maxWaitTimeoutRef.current);
      maxWaitTimeoutRef.current = null;
    }
    lastArgsRef.current = null;
    pendingRef.current = false;
  }, []);
  
  // Executa imediatamente
  const flush = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    if (maxWaitTimeoutRef.current) {
      clearTimeout(maxWaitTimeoutRef.current);
      maxWaitTimeoutRef.current = null;
    }
    invokeCallback();
  }, [invokeCallback]);
  
  // Função debounced
  const debouncedFn = useCallback((...args: Parameters<T>) => {
    const now = Date.now();
    const timeSinceLastCall = now - lastCallTimeRef.current;
    const timeSinceLastInvoke = now - lastInvokeTimeRef.current;
    
    lastCallTimeRef.current = now;
    lastArgsRef.current = args;
    pendingRef.current = true;
    
    // Leading edge: executa na primeira chamada se passou delay desde última invocação
    if (leading && timeSinceLastInvoke >= delay) {
      invokeCallback();
      return;
    }
    
    // Limpa timeout anterior
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    // MaxWait: garante execução mesmo com chamadas contínuas
    if (maxWait && !maxWaitTimeoutRef.current) {
      const remainingMaxWait = maxWait - timeSinceLastInvoke;
      
      if (remainingMaxWait <= 0) {
        invokeCallback();
      } else {
        maxWaitTimeoutRef.current = setTimeout(() => {
          maxWaitTimeoutRef.current = null;
          if (pendingRef.current) {
            invokeCallback();
          }
        }, remainingMaxWait);
      }
    }
    
    // Trailing edge: agenda execução após delay
    if (trailing) {
      timeoutRef.current = setTimeout(() => {
        timeoutRef.current = null;
        if (maxWaitTimeoutRef.current) {
          clearTimeout(maxWaitTimeoutRef.current);
          maxWaitTimeoutRef.current = null;
        }
        invokeCallback();
      }, delay);
    }
  }, [delay, leading, trailing, maxWait, invokeCallback]) as T;
  
  return useMemo(() => ({
    debouncedFn,
    cancel,
    flush,
    get isPending() { return pendingRef.current; },
  }), [debouncedFn, cancel, flush]);
}

/**
 * Hook para throttle (limite de taxa de execução)
 * Garante que a função seja executada no máximo uma vez por intervalo
 */
export function useThrottle<T>(value: T, interval: number): T {
  const [throttledValue, setThrottledValue] = useState<T>(value);
  const lastExecutedRef = useRef<number>(Date.now());
  
  useEffect(() => {
    const now = Date.now();
    const timeSinceLastExecution = now - lastExecutedRef.current;
    
    if (timeSinceLastExecution >= interval) {
      lastExecutedRef.current = now;
      setThrottledValue(value);
    } else {
      const timeoutId = setTimeout(() => {
        lastExecutedRef.current = Date.now();
        setThrottledValue(value);
      }, interval - timeSinceLastExecution);
      
      return () => clearTimeout(timeoutId);
    }
  }, [value, interval]);
  
  return throttledValue;
}

/**
 * Hook para throttle de callbacks
 */
export function useThrottledCallback<T extends (...args: any[]) => any>(
  callback: T,
  interval: number
): T {
  const callbackRef = useRef(callback);
  const lastExecutedRef = useRef<number>(0);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastArgsRef = useRef<Parameters<T> | null>(null);
  
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);
  
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);
  
  return useCallback((...args: Parameters<T>) => {
    const now = Date.now();
    const timeSinceLastExecution = now - lastExecutedRef.current;
    
    lastArgsRef.current = args;
    
    if (timeSinceLastExecution >= interval) {
      lastExecutedRef.current = now;
      callbackRef.current(...args);
    } else if (!timeoutRef.current) {
      timeoutRef.current = setTimeout(() => {
        lastExecutedRef.current = Date.now();
        if (lastArgsRef.current) {
          callbackRef.current(...lastArgsRef.current);
        }
        timeoutRef.current = null;
      }, interval - timeSinceLastExecution);
    }
  }, [interval]) as T;
}

export default useDebounce;
