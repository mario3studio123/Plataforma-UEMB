// src/hooks/core/useRetry.ts
// Hook para executar operações assíncronas com retry automático
// Integra o sistema de recovery com React de forma segura

import { useState, useCallback, useRef, useEffect } from 'react';
import { 
  withRetry, 
  RetryConfig, 
  RETRY_CONFIGS 
} from '@/lib/errors/recovery';
import { AppError, normalizeError } from '@/lib/errors';
import { useMounted } from './useMounted';

/**
 * Estado do hook useRetry
 */
export interface UseRetryState<T> {
  /** Dados retornados pela operação (se sucesso) */
  data: T | null;
  
  /** Erro da última tentativa (se falhou) */
  error: AppError | null;
  
  /** Se está executando a operação */
  isLoading: boolean;
  
  /** Se a operação foi bem sucedida */
  isSuccess: boolean;
  
  /** Se a operação falhou após todas as tentativas */
  isError: boolean;
  
  /** Número de tentativas realizadas */
  attemptCount: number;
  
  /** Se está fazendo retry no momento */
  isRetrying: boolean;
}

/**
 * Opções do hook useRetry
 */
export interface UseRetryOptions<T> {
  /** Configuração de retry (padrão: NETWORK) */
  retryConfig?: Partial<RetryConfig>;
  
  /** Se deve executar automaticamente no mount */
  immediate?: boolean;
  
  /** Callback quando a operação tem sucesso */
  onSuccess?: (data: T) => void;
  
  /** Callback quando a operação falha após todas as tentativas */
  onError?: (error: AppError) => void;
  
  /** Callback chamado a cada retry */
  onRetry?: (error: AppError, attempt: number) => void;
  
  /** Valor inicial dos dados */
  initialData?: T | null;
}

/**
 * Resultado do hook useRetry
 */
export interface UseRetryResult<T> extends UseRetryState<T> {
  /** Executa a operação com retry */
  execute: () => Promise<T | null>;
  
  /** Reseta o estado para inicial */
  reset: () => void;
  
  /** Cancela a operação em andamento */
  cancel: () => void;
}

/**
 * Hook para executar operações assíncronas com retry automático
 * 
 * @example
 * // Uso básico
 * const { data, isLoading, execute } = useRetry(
 *   () => fetchUserProfile(userId),
 *   { immediate: true }
 * );
 * 
 * @example
 * // Com callbacks
 * const { execute, isRetrying } = useRetry(
 *   () => saveProgress(progress),
 *   {
 *     onSuccess: () => toast('Progresso salvo!'),
 *     onError: (err) => toast(err.message, 'error'),
 *     onRetry: (_, attempt) => console.log(`Tentativa ${attempt}...`),
 *   }
 * );
 */
export function useRetry<T>(
  operation: () => Promise<T>,
  options: UseRetryOptions<T> = {}
): UseRetryResult<T> {
  const {
    retryConfig,
    immediate = false,
    onSuccess,
    onError,
    onRetry,
    initialData = null,
  } = options;

  const isMounted = useMounted();
  const abortControllerRef = useRef<AbortController | null>(null);
  const operationRef = useRef(operation);
  
  // Atualiza ref da operação sem causar re-render
  operationRef.current = operation;

  // Estado
  const [state, setState] = useState<UseRetryState<T>>({
    data: initialData,
    error: null,
    isLoading: false,
    isSuccess: false,
    isError: false,
    attemptCount: 0,
    isRetrying: false,
  });

  // Cleanup no unmount
  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  // Função de execução
  const execute = useCallback(async (): Promise<T | null> => {
    // Cancela operação anterior se existir
    abortControllerRef.current?.abort();
    abortControllerRef.current = new AbortController();

    if (!isMounted()) return null;

    setState(prev => ({
      ...prev,
      isLoading: true,
      isSuccess: false,
      isError: false,
      error: null,
      attemptCount: 0,
      isRetrying: false,
    }));

    try {
      // Configura retry com callbacks
      const config: Partial<RetryConfig> = {
        ...RETRY_CONFIGS.NETWORK,
        ...retryConfig,
        onRetry: (error, attempt, delayMs) => {
          if (!isMounted()) return;
          
          setState(prev => ({
            ...prev,
            attemptCount: attempt,
            isRetrying: true,
          }));
          
          onRetry?.(error, attempt);
          retryConfig?.onRetry?.(error, attempt, delayMs);
        },
      };

      const result = await withRetry(
        operationRef.current,
        config,
        'useRetry-operation'
      );

      if (!isMounted()) return null;

      setState({
        data: result,
        error: null,
        isLoading: false,
        isSuccess: true,
        isError: false,
        attemptCount: state.attemptCount + 1,
        isRetrying: false,
      });

      onSuccess?.(result);
      return result;

    } catch (error) {
      if (!isMounted()) return null;

      const appError = normalizeError(error);
      
      setState(prev => ({
        ...prev,
        data: null,
        error: appError,
        isLoading: false,
        isSuccess: false,
        isError: true,
        isRetrying: false,
      }));

      onError?.(appError);
      return null;
    }
  }, [isMounted, retryConfig, onSuccess, onError, onRetry, state.attemptCount]);

  // Reset do estado
  const reset = useCallback(() => {
    abortControllerRef.current?.abort();
    
    setState({
      data: initialData,
      error: null,
      isLoading: false,
      isSuccess: false,
      isError: false,
      attemptCount: 0,
      isRetrying: false,
    });
  }, [initialData]);

  // Cancelamento
  const cancel = useCallback(() => {
    abortControllerRef.current?.abort();
    
    if (isMounted()) {
      setState(prev => ({
        ...prev,
        isLoading: false,
        isRetrying: false,
      }));
    }
  }, [isMounted]);

  // Execução imediata se configurado
  useEffect(() => {
    if (immediate) {
      execute();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [immediate]);

  return {
    ...state,
    execute,
    reset,
    cancel,
  };
}

/**
 * Hook para operações de mutação (POST, PUT, DELETE) com retry
 * Similar ao useMutation do React Query mas com retry integrado
 */
export function useRetryMutation<TData, TVariables>(
  mutationFn: (variables: TVariables) => Promise<TData>,
  options: Omit<UseRetryOptions<TData>, 'immediate'> = {}
): UseRetryResult<TData> & {
  mutate: (variables: TVariables) => Promise<TData | null>;
} {
  const [variables, setVariables] = useState<TVariables | null>(null);
  
  const result = useRetry(
    () => {
      if (variables === null) {
        throw new Error('Variables not set');
      }
      return mutationFn(variables);
    },
    { ...options, immediate: false }
  );

  const mutate = useCallback(async (vars: TVariables): Promise<TData | null> => {
    setVariables(vars);
    // Pequeno delay para garantir que o state atualizou
    await new Promise(resolve => setTimeout(resolve, 0));
    return result.execute();
  }, [result]);

  return {
    ...result,
    mutate,
  };
}

export default useRetry;
