// src/hooks/useDebounce.ts
// Re-exporta do módulo core para manter compatibilidade
// O módulo core tem versão mais completa com leading/trailing e throttle

export { 
  useDebounce, 
  useDebouncedCallback, 
  useThrottle, 
  useThrottledCallback 
} from './core/useDebounce';