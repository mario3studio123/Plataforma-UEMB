// src/hooks/core/useAsyncEffect.ts
// Hook para operações assíncronas com cleanup automático e suporte a abort
// Resolve race conditions e memory leaks em operações async

import { useEffect, useRef, useCallback, DependencyList } from 'react';

/**
 * Status da operação assíncrona
 */
export type AsyncEffectStatus = 'idle' | 'pending' | 'success' | 'error' | 'cancelled';

/**
 * Opções do useAsyncEffect
 */
export interface AsyncEffectOptions {
  /** Callback chamado quando a operação inicia */
  onStart?: () => void;
  
  /** Callback chamado quando a operação tem sucesso */
  onSuccess?: () => void;
  
  /** Callback chamado quando ocorre erro */
  onError?: (error: Error) => void;
  
  /** Callback chamado quando a operação é cancelada */
  onCancel?: () => void;
  
  /** Se deve logar erros no console (default: true em dev) */
  logErrors?: boolean;
}

/**
 * Resultado retornado pelo useAsyncEffect
 */
export interface AsyncEffectResult {
  /** Status atual da operação */
  status: AsyncEffectStatus;
  
  /** Último erro ocorrido */
  error: Error | null;
  
  /** Função para cancelar a operação manualmente */
  cancel: () => void;
  
  /** Função para re-executar a operação */
  retry: () => void;
}

/**
 * Hook para executar efeitos assíncronos de forma segura
 * 
 * @param effect - Função async que recebe AbortSignal
 * @param deps - Dependências do efeito
 * @param options - Opções adicionais
 * 
 * @example
 * // Uso básico
 * useAsyncEffect(
 *   async (signal) => {
 *     const response = await fetch('/api/data', { signal });
 *     const data = await response.json();
 *     setData(data);
 *   },
 *   [userId]
 * );
 * 
 * @example
 * // Com callbacks
 * const { status, error, retry } = useAsyncEffect(
 *   async (signal) => {
 *     const data = await fetchWithRetry('/api/data', { signal });
 *     setData(data);
 *   },
 *   [userId],
 *   {
 *     onError: (err) => addToast(err.message, 'error'),
 *     onSuccess: () => addToast('Dados carregados!', 'success'),
 *   }
 * );
 */
export function useAsyncEffect(
  effect: (signal: AbortSignal) => Promise<void>,
  deps: DependencyList,
  options: AsyncEffectOptions = {}
): AsyncEffectResult {
  const {
    onStart,
    onSuccess,
    onError,
    onCancel,
    logErrors = process.env.NODE_ENV === 'development',
  } = options;
  
  // Refs para manter estado entre renders
  const statusRef = useRef<AsyncEffectStatus>('idle');
  const errorRef = useRef<Error | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const effectRef = useRef(effect);
  const retryCountRef = useRef(0);
  
  // Atualiza ref do effect sem disparar re-render
  effectRef.current = effect;
  
  // Função para cancelar operação
  const cancel = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      statusRef.current = 'cancelled';
      onCancel?.();
    }
  }, [onCancel]);
  
  // Função para executar o efeito
  const runEffect = useCallback(async () => {
    // Cancela qualquer operação anterior
    cancel();
    
    // Cria novo AbortController
    const abortController = new AbortController();
    abortControllerRef.current = abortController;
    
    statusRef.current = 'pending';
    errorRef.current = null;
    onStart?.();
    
    try {
      await effectRef.current(abortController.signal);
      
      // Verifica se não foi cancelado durante a execução
      if (!abortController.signal.aborted) {
        statusRef.current = 'success';
        onSuccess?.();
      }
    } catch (error) {
      // Ignora erros de abort
      if (error instanceof Error && error.name === 'AbortError') {
        statusRef.current = 'cancelled';
        onCancel?.();
        return;
      }
      
      // Só processa erro se não foi cancelado
      if (!abortController.signal.aborted) {
        const err = error instanceof Error ? error : new Error(String(error));
        statusRef.current = 'error';
        errorRef.current = err;
        
        if (logErrors) {
          console.error('[useAsyncEffect] Error:', err);
        }
        
        onError?.(err);
      }
    }
  }, [cancel, onStart, onSuccess, onCancel, onError, logErrors]);
  
  // Função para retry
  const retry = useCallback(() => {
    retryCountRef.current++;
    runEffect();
  }, [runEffect]);
  
  // Efeito principal
  useEffect(() => {
    runEffect();
    
    // Cleanup: cancela na desmontagem
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
        abortControllerRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  
  return {
    status: statusRef.current,
    error: errorRef.current,
    cancel,
    retry,
  };
}

/**
 * Versão simplificada sem retorno de status
 * Para casos onde você só precisa do cleanup automático
 */
export function useAsyncEffectSimple(
  effect: (signal: AbortSignal) => Promise<void>,
  deps: DependencyList
): void {
  useAsyncEffect(effect, deps);
}

/**
 * Hook para executar efeito apenas uma vez (mount)
 */
export function useAsyncMount(
  effect: (signal: AbortSignal) => Promise<void>,
  options?: AsyncEffectOptions
): AsyncEffectResult {
  return useAsyncEffect(effect, [], options);
}

/**
 * Hook para executar efeito com condição
 */
export function useAsyncEffectIf(
  condition: boolean,
  effect: (signal: AbortSignal) => Promise<void>,
  deps: DependencyList,
  options?: AsyncEffectOptions
): AsyncEffectResult {
  const wrappedEffect = useCallback(async (signal: AbortSignal) => {
    if (condition) {
      await effect(signal);
    }
  }, [condition, effect]);
  
  return useAsyncEffect(wrappedEffect, [condition, ...deps], options);
}

/**
 * Hook para executar múltiplos efeitos em paralelo
 */
export function useAsyncEffectAll(
  effects: Array<(signal: AbortSignal) => Promise<void>>,
  deps: DependencyList,
  options?: AsyncEffectOptions
): AsyncEffectResult {
  const combinedEffect = useCallback(async (signal: AbortSignal) => {
    await Promise.all(effects.map(effect => effect(signal)));
  }, [effects]);
  
  return useAsyncEffect(combinedEffect, deps, options);
}

export default useAsyncEffect;
